//
//  TrackerViewViewModel.swift
//  FINAL
//
//  Created by Andrew Parker on 5/9/24.
//

import Foundation

class TrackerViewViewModel: ObservableObject {
    
    init() {}
}
