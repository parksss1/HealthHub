//
//  FINALApp.swift
//  FINAL
//
//  Created by Andrew Parker on 5/7/24.
//
import FirebaseCore
import SwiftUI

@main
struct FINALApp: App {
    @StateObject var manager = HealthManager()
    init() {
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            MainView()
                .environmentObject(manager)
        }
    }
}
