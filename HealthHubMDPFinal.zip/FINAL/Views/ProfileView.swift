//
//  ProfileView.swift
//  FINAL
//
//  Created by Andrew Parker on 5/7/24.
//

import SwiftUI

struct ProfileView: View {
    @StateObject var viewModel = ProfileViewViewModel()
    var body: some View {
        NavigationView {
            VStack {
                if let user = viewModel.user {
                    profile(user: user)
                    } else {
                        Text("Loading profile")
                }
                
            }
            .navigationTitle("Profile")
        }
        .onAppear{
            viewModel.fetchUser()
            }
    }
    
    
    @ViewBuilder
    func profile(user: User) -> some View {
        Image(systemName: "person.circle")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .foregroundColor(.blue)
            .frame(width: 125, height: 125)
            .padding()
        VStack(alignment: .leading) {
            HStack {
                Text("Name: ")
                    .bold()
                Text(user.name)
            }
            .padding()
            HStack {
                Text("Email: ")
                    .bold()
                Text(user.email)
            }
            .padding()
            HStack {
                Text("Member Since: ")
                    .bold()
                Text("\(Date(timeIntervalSince1970: user.joined).formatted(date: .abbreviated, time: .shortened))")
            }
            .padding()
            HStack {
                Text("Height: ")
                    .bold()
                Text("\(user.height)")
            }
            .padding()
            HStack {
                Text("Weight (lbs): ")
                    .bold()
                Text(user.weight)
            }
            .padding()
            HStack {
                Text("Age: ")
                    .bold()
                Text("\(user.age)")
            }
            .padding()
            Button("Log Out") {
                viewModel.logOut()
            }
            .tint(.red)
            .padding()
            Spacer()
            }
    }
}

#Preview {
    ProfileView()
}
