//
//  RegisterView.swift
//  FINAL
//
//  Created by Andrew Parker on 5/7/24.
//

import SwiftUI

struct RegisterView: View {
    @StateObject var viewModel = RegisterViewViewModel()
    var body: some View {
        VStack {
            // header
            Spacer()
            Spacer()
            HeaderView(title: "Register",
                       background: .red)
            Form {
                TextField("Full Name", text: $viewModel.name)
                    .textFieldStyle(DefaultTextFieldStyle())
                TextField("Email Address", text: $viewModel.email)
                    .textFieldStyle(DefaultTextFieldStyle())
                    .autocapitalization(.none)
                    .autocorrectionDisabled()
                Picker("Height", selection: $viewModel.height) {
                    ForEach(viewModel.heights, id: \.self) { height in Text("\(height) in")
                    }
                }
                .pickerStyle(MenuPickerStyle())
                TextField("Weight", text: $viewModel.weight)
                    .textFieldStyle(DefaultTextFieldStyle())
                    .autocapitalization(.none)
                    .autocorrectionDisabled()
                Picker("Age", selection: $viewModel.age) {
                    ForEach(viewModel.ages, id: \.self) { age in
                        Text("\(age) years")
                        }
                }
                    .pickerStyle(MenuPickerStyle())
                TextField("Password", text: $viewModel.password)
                    .textFieldStyle(DefaultTextFieldStyle())
                    .autocapitalization(.none)
                TLButton(title: "Create Account",
                         background: .green
                ) {
                    viewModel.register()
                }
            }
            .offset(y: -50)
            
            Spacer()
        }
    }
}

#Preview {
    RegisterView()
}
