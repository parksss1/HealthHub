//
//  HeaderView.swift
//  FINAL
//
//  Created by Andrew Parker on 5/8/24.
//

import SwiftUI

struct HeaderView: View {
    let title: String
    let background: Color
    
    var body: some View {
        ZStack {
            // Background
            Rectangle()
                .foregroundColor(background)
                .frame(height: 120)  // Fixed height for uniformity
                .edgesIgnoringSafeArea(.top)
            
            // Title
            Text(title)
                .font(.largeTitle)  // Using built-in text styles for better scalability
                .foregroundColor(.white)
                .bold()
                .shadow(radius: 3)  // Optional shadow for depth
        }
    }
}

#Preview {
    HeaderView(title: "Main Screen",
               background: .blue)
}
