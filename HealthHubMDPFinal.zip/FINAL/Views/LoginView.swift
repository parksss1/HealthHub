//
//  LoginView.swift
//  FINAL
//
//  Created by Andrew Parker on 5/7/24.
//

import SwiftUI

struct LoginView: View {
    @StateObject var viewModel = LoginViewViewModel()
    var body: some View {
        NavigationView {
            VStack {
                // header
                Spacer()
                HeaderView(title: "Login",
                           background: .blue)
                
                // login form

                Form {
                    
                    if !viewModel.errorMessage.isEmpty {
                        Text(viewModel.errorMessage)
                            .foregroundColor(Color.red)
                    }
                    
                    TextField("Email Address", text: $viewModel.email)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .autocapitalization(.none)
                        .autocorrectionDisabled()
                    
                    TextField("Password", text: $viewModel.password)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .autocapitalization(.none)
                        .autocorrectionDisabled()
                    
                   TLButton(title: "Login",
                            background: .blue
                   ) {
                       viewModel.login()
                   }
                    
                }
                //create account
                
                VStack {
                    Text("Don't Have an Account?")
                   
                    NavigationLink("Create an Account!",
                                   destination: RegisterView())
                }
                .padding(.bottom)
                Spacer()
                Spacer()
            }
        }
    }
}

#Preview {
    LoginView()
}
