//
//  TrackerView.swift
//  FINAL
//
//  Created by Andrew Parker on 5/9/24.
//

import SwiftUI

struct TrackerView: View {
    @StateObject var viewModel = TrackerViewViewModel()
    @EnvironmentObject var manager: HealthManager
    @State var selectedTab = "Home"
    
    private let userId: String
    init(userId: String) {
        self.userId = userId
    }
    var body: some View {
        NavigationView {
            TabView(selection: $selectedTab) {
                HomeView()
                    //.environmentObject(manager)
                    .tag("Home")
                    
                    .environmentObject(manager)
                
                ProfileView()
                    .tag("Content")
                    
            }
        }
    }
}

#Preview {
    TrackerView(userId: "")
        .environmentObject(HealthManager())
}
