 //
//  ContentView.swift
//  FINAL
//
//  Created by Andrew Parker on 5/7/24.
//

import SwiftUI

struct MainView: View {
    @StateObject var viewModel = MainViewViewModel()
    var body: some View {
        if viewModel.isSignedIn, !viewModel.currentUserId.isEmpty {
            account
        } else {
            LoginView()
        }
    }
    
    @ViewBuilder
    var account: some View {
        TabView {
            TrackerView(userId: viewModel.currentUserId)
                .tabItem {
                    Label("Home", systemImage: "house")
                }
            
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.circle")
                }
        }
    }
}

#Preview {
    MainView()
}
