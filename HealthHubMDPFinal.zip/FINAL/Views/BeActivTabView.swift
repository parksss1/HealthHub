//
//  BeActiveTabView.swift
//  FINAL
//
//  Created by Andrew Parker on 5/9/24.
//

import SwiftUI

struct BeActivTabView: View {
    @EnvironmentObject var manager: HealthManager
    @State var selectedTab = "Home"
    
    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView()
                //.environmentObject(manager)
                .tag("Home")
                .tabItem {
                    Image(systemName: "figure.stand")
                }
                .environmentObject(manager)
            
            ProfileView()
                .tag("Content")
                .tabItem {
                    Image(systemName: "person")
                }
        }
    }
}

struct BeActivTabView_Previews: PreviewProvider {
    static var previews: some View {
        BeActivTabView()
            .environmentObject(HealthManager())
    }
}
